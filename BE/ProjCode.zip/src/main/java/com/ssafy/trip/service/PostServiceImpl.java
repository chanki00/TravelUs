package com.ssafy.trip.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.ssafy.trip.dto.Post;
import com.ssafy.trip.repository.PostRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class PostServiceImpl implements PostService{
	private final PostRepository repo;

	public int createRecruitPost(Post req) {
		return repo.createRecruitPost(req);
	}

	public List<Post> getALlRecruitPost() {
		return repo.getALlRecruitPost();
	}
}
