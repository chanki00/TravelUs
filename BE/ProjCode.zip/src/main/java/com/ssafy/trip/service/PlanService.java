package com.ssafy.trip.service;

import java.util.Iterator;
import java.util.List;

import org.springframework.stereotype.Service;

import com.ssafy.trip.dto.BasicPlanDTO;
import com.ssafy.trip.dto.Itinerary;
import com.ssafy.trip.dto.ItineraryPlaceResponseDto;
import com.ssafy.trip.dto.Tripplan;
import com.ssafy.trip.repository.PlanRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class PlanService {
	
	private final PlanRepository repo;
	
	public int insert(Tripplan dto) {
		 try {
			 	int res = repo.insert(dto); 
			 	makeDaysPlan(dto);
		        return res; // 예: DB 삽입 시 오류 발생 가능
		    } catch (Exception e) {
		        throw e;
		    }
	}

	public void makeDaysPlan(Tripplan dto) {
		for (int day = 1; day <= dto.getDuration() ; day++) {
			repo.insertDay(dto.getId(), day);
		}
	}

	public Tripplan getTripplanById(int planId) {
        return repo.selectTripplanById(planId);
    }

	public int getPlanDaysId(int planId, int dayNumber) {
		return repo.getPlanDaysId(planId, dayNumber);
	}

	public int insertItinerary(Itinerary req) {
		return repo.insertItinerary(req);
	}

	public List<Tripplan> getTripplanByUserId(int userId) {
		return repo.getTripplanByUserId(userId);
	}

	public int updateShare(int planId) {
		return repo.updateShare(planId);
	}

	public List<Tripplan> getAllSharePlan() {
		return repo.getAllSharePlan();
	}

	public List<ItineraryPlaceResponseDto> getItineraryByPlanId(int planId) {
		return repo.getItineraryByPlanId(planId);
	}

}
