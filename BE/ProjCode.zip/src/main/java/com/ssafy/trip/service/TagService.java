package com.ssafy.trip.service;

import java.util.List;

import com.ssafy.trip.dto.TagDTO;

public interface TagService {

	List<TagDTO> getTripTags();

}
