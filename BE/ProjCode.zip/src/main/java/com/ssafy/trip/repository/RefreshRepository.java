package com.ssafy.trip.repository;

import org.apache.ibatis.annotations.Mapper;

import com.ssafy.trip.dto.RefreshToken;

@Mapper
public interface RefreshRepository {
    void saveToken(RefreshToken token); // INSERT OR UPDATE
    RefreshToken findByUsername(String username);
    void deleteToken(String username);
}
