package com.ssafy.trip.dto;

import lombok.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class RefreshToken {
    private String username;
    private String token;
}