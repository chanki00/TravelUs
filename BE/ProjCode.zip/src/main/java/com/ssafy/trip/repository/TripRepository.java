package com.ssafy.trip.repository;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.ssafy.trip.dto.Attraction;
import com.ssafy.trip.dto.Sido;

@Mapper
public interface TripRepository {

	List<Sido> getSidoList();

		List<Attraction> getAttractionBysidoCode(int sidoCode);

}
