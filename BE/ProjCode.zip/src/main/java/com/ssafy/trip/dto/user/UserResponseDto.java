package com.ssafy.trip.dto.user;

import java.time.LocalDateTime;

import com.ssafy.trip.dto.user.enums.Gender;
import com.ssafy.trip.dto.user.enums.Role;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class UserResponseDto {
    private Long id;
    private String userId;
    private String userEmail;
    private String name;
    private String age;
    private Gender gender;
    private String address;
    private String intro;
    private Role role;
    private Boolean allowInvite;
}
