package com.ssafy.trip.controller;

import java.util.Map;

import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ssafy.trip.service.AiChatService;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/ai")
@RequiredArgsConstructor
@Slf4j
public class AIChatController {
	private final AiChatService chatService;
	
	@PostMapping("/simple")
    ResponseEntity<?> simpleGeneration(@RequestBody Map<String, String> userInput) {
        Object result = chatService.simpleGeneration(userInput.get("message"));
        
        return ResponseEntity.ok(Map.of(
                "status", "SUCCESS",
                "message", result
            ));
    }
	@PostMapping("/trip-plan")
    ResponseEntity<?> generateTripPlan(@RequestBody Map<String, Object> tripRequest) {
        log.info("여행 계획 생성 요청: {}", tripRequest);
        
        // 여행 계획 생성을 위한 프롬프트 구성
        StringBuilder prompt = new StringBuilder();
        prompt.append("다음 조건에 맞는 여행 계획을 만들어주세요:\n");
        
        if (tripRequest.containsKey("destination")) {
            prompt.append("- 여행지: ").append(tripRequest.get("destination")).append("\n");
        }
        
        if (tripRequest.containsKey("duration")) {
            prompt.append("- 기간: ").append(tripRequest.get("duration")).append("박 ")
                  .append(Integer.parseInt(tripRequest.get("duration").toString()) + 1).append("일\n");
        }
        
        if (tripRequest.containsKey("style")) {
            prompt.append("- 여행 스타일: ").append(tripRequest.get("style")).append("\n");
        }
        
        if (tripRequest.containsKey("companions")) {
            prompt.append("- 동행자: ").append(tripRequest.get("companions")).append("\n");
        }
        
        if (tripRequest.containsKey("budget")) {
            prompt.append("- 예산: ").append(tripRequest.get("budget")).append("\n");
        }
        
        prompt.append("\n다음 형식으로 응답해주세요:\n");
        prompt.append("1. 여행 계획 개요 (제목, 설명)\n");
        prompt.append("2. 일차별 일정 (각 일차마다 방문할 장소 3-4곳, 각 장소에 대한 간략한 설명)\n");
        prompt.append("3. 추천 맛집\n");
        prompt.append("4. 여행 팁\n\n");
        prompt.append("JSON 형식으로 응답해주세요.");
        
        // AI 서비스 호출
        Object result = chatService.simpleGeneration(prompt.toString());
        log.info("AI 여행 계획 응답: {}", result);
        
        return ResponseEntity.ok(Map.of(
                "status", "SUCCESS",
                "message", result
            ));
    }
}
