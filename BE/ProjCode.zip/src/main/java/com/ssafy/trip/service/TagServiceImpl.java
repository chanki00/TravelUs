package com.ssafy.trip.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.ssafy.trip.dto.TagDTO;
import com.ssafy.trip.repository.TagRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class TagServiceImpl implements TagService{
	
	private final TagRepository repo;
	
	@Override
	public List<TagDTO> getTripTags() {
		return repo.getTripTags();
	}

	public int insertplanTag(int planId, int tagId) {
		return repo.insertplanTag(planId,tagId);
	}

	public List<String> getTripplanTagsName(int planId) {
		return repo.getTripplanTagsName(planId);
	}
	
	public List<TagDTO> getUserTags() {
		return repo.getUserTags();
	}
	
	public int insertUserTag(int userId, int tagId) {
		return repo.insertUserTag(userId, tagId);
	}
	
	public List<String> getUserPersonalTagsName(int userId) {
		return repo.getUserPersonalTagsName(userId);
	}

	public List<String> getUserTripTagsName(int userId) {
		return repo.getUserTripTagsName(userId);
	}
	
	public void updateUserTags(int userId, String type, List<Integer> tagIds) {
	    repo.deleteUserTags(userId, type); // 기존 유저 태그 삭제
	    for (Integer tagId : tagIds) {
	        repo.insertUserTag(userId, tagId); // 새 태그 등록
	    }
	}

}
