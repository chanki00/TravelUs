package com.ssafy.trip.service;

import java.util.List;

import com.ssafy.trip.dto.Sido;

public interface TripService {

	List<Sido> getSidoList();

}
