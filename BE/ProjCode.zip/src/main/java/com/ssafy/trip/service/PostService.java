package com.ssafy.trip.service;

public interface PostService {

}
