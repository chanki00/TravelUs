package com.ssafy.trip.repository;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.ssafy.trip.dto.TagDTO;

@Mapper
public interface TagRepository {

	List<TagDTO> getTripTags();
	int insertplanTag(int planId, int tagId);
	List<String> getTripplanTagsName(int planId);
	
	List<TagDTO> getUserTags();
	int insertUserTag(int userId, int tagId);
	List<String> getUserPersonalTagsName(int userId);
	List<String> getUserTripTagsName(int userId);
	
    int deleteUserTags(int userId, String type);
}
