package com.ssafy.trip.repository;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.ssafy.trip.dto.Post;

@Mapper
public interface PostRepository {

	int createRecruitPost(Post req);

	List<Post> getALlRecruitPost();

}
