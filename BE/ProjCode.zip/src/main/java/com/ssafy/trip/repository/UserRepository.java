package com.ssafy.trip.repository;

import java.sql.SQLException;
import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.ssafy.trip.dto.user.UserDto;
import com.ssafy.trip.dto.user.UserInfoDto;
import com.ssafy.trip.dto.user.UserPwDto;

@Mapper
public interface UserRepository {
	public int insertUser(UserDto user) throws SQLException;
	public UserDto selectUser(Long id) throws SQLException;
	public UserDto selectUserByUserid(String userId) throws SQLException;
	public List<UserDto> selectAllUser() throws SQLException;
	public int updateInfo(UserInfoDto dto) throws SQLException;
	public int updatePw(UserPwDto dto) throws SQLException;
	public int deleteUser(Long id) throws SQLException;
}
