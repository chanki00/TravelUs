package com.ssafy.trip;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Daejeon513FinalprojectTravelusApplicationTests {

	@Test
	void contextLoads() {
	}

}
