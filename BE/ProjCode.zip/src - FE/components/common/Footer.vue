<template>
  <footer class="bg-background border-t py-12 mt-auto">
  <div class="container flex flex-col items-center text-center gap-8">
    <!-- 상단 Travelus 로고 + 설명 -->
    <div class="space-y-4">
      <div class="flex items-center justify-center gap-2 font-bold text-xl">
        <div class="w-8 h-8 rounded-full bg-gradient-to-r from-blue-500 to-blue-600 flex items-center justify-center">
          <span class="text-white font-bold text-sm">T</span>
        </div>
        <span>Travelus</span>
      </div>
      <p class="text-sm text-muted-foreground">
        AI 기반 여행 플래너 & 동행 매칭 플랫폼
      </p>
      <div class="flex justify-center space-x-4">
        <!-- SNS 아이콘들 -->
      </div>
    </div>

    <!-- 링크 그룹들 -->
    <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-8 w-full max-w-5xl text-left">
      <!-- 서비스 / 회사 / 법적 정보 섹션들 -->
    </div>

    <!-- 하단 카피라이트 -->
    <div class="w-full pt-8 border-t">
      <p class="text-sm text-muted-foreground text-center">
        © 2023 Travelus. All rights reserved.
      </p>
    </div>
  </div>
</footer>

</template>

<script setup>
// 여기에 script 로직이 추가될 예정
</script>

<style scoped>
/* 필요한 스타일 추가 */
</style>
